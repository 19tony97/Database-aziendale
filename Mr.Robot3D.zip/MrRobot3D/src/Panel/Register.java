package Panel;

import java.io.*;  
import java.sql.*;  
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;  
  
@WebServlet("/register")
public class Register extends HttpServlet {  
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
		
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  
		
		String n=request.getParameter("Nome"); 
		String c=request.getParameter("Cognome");  
		String s=request.getParameter("Sesso");  
		String i=request.getParameter("Indirizzo");  
		String pa=request.getParameter("PayPal");
		String e=request.getParameter("Email");  
		String p=request.getParameter("Password"); 
		
		if (request.getParameter("azione").equals("Registrati")) {
		try {  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mrrobot3d","root","root");  
			
			PreparedStatement ps=con.prepareStatement("insert into utente (Nome, Cognome, Sesso, Indirizzo, PayPal, Email, Password) "
					+ "values(?,?,?,?,?,?,?)"); 
			
			ps.setString(1,n);  
			ps.setString(2,c);  
			ps.setString(3,s);  
			ps.setString(4,i);  
			ps.setString(5,pa); 
			ps.setString(6,e); 
			ps.setString(7,p); 
			
			int z=ps.executeUpdate(); 
			
			if(z>0)  {
				out.print("<script type=\"text/javascript\">" +
					"alert (\"Registrazione eseguita con successo!\""
					+ "</script>");
			request.getRequestDispatcher("index.jsp").include(request, response);
			}
			else {
				out.print("<script type=\"text/javascript\">" +
						"alert (\"E-mail gi� presente nel sistema!\""
						+ "</script>");
				request.getRequestDispatcher("registrazione.jsp").include(request, response);
			}
			
		
			   
		} catch (Exception e2) {
			System.out.println(e2);
			}  
		}
			
		out.close();  
}  
  
} 