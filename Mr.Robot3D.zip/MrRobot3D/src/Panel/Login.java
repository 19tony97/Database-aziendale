package Panel;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Statement;

@WebServlet("/login")
public class Login extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    public Login() {
        super();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();  
		
		String e=request.getParameter("Email"); 
		String p=request.getParameter("Password"); 
		
		try {  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mrrobot3d","root","root");  
			
			Statement stmt = (Statement) con.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM utente\r\n" + 
					"WHERE Email = \""+ e +"\" and Password = \""+ p + "\""); 
			  
			 if (rs.next()){
				 
				boolean a = rs.getBoolean("Admin");
				 
				HttpSession session = request.getSession();
				String strLogin = request.getParameter("Email");
				session.setAttribute("Email", strLogin);
				session.setAttribute("Admin", a);  
				request.getRequestDispatcher("index.jsp").include(request, response);
				
				
			 }
			 else { 
		            request.getRequestDispatcher("login.jsp").include(request, response);
			 }
		} catch (Exception e2) {
			System.out.println(e2);
			}  
		
		out.close();  
		}

}
