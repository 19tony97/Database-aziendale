package Panel;

import java.util.ArrayList;

public class Catalogo {
    
   ArrayList<Item> oggetti_catalogo;
    
   public Catalogo() {
           oggetti_catalogo = new ArrayList<Item>();
   }
        
   public void aggiungi(Item oggetto) {
           oggetti_catalogo.add(oggetto);
   }
   public void rimuovi(Item oggetto) {
           oggetti_catalogo.remove(oggetto);
   }   
   public ArrayList<Item> getOggettiCatalogo() {
           return oggetti_catalogo;
   }

}