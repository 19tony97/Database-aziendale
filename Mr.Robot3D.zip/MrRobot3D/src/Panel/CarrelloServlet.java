package Panel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/carrelloServlet")
public class CarrelloServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	Carrello carrello = new Carrello() ;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	
    	HttpSession session = request.getSession();
    	String strLogin = (String) session.getAttribute("Email");
    	if (strLogin == null)
    	{
    	response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	out.println("Utente non registrato!");
    	request.getRequestDispatcher("login.jsp").include(request, response);
    	out.close();
    	return;
    	}    	
    	
    	Item oggetto = new Item();
    	
    	if (request.getParameter("azione").equals("Aggiungi al carrello")) {
    		int order;
    	
    		oggetto.setNome(request.getParameter("NomeA"));
            oggetto.setDescrizione(request.getParameter("Descrizione"));
            oggetto.setPrezzo(Double.parseDouble(request.getParameter("Prezzo")));
            oggetto.setQuantit�(Integer.parseInt(request.getParameter("Quantit�")));
            order = Integer.parseInt( request.getParameter("order") );
            if ( order > oggetto.getQuantit�() )
				
					new Exception("Non ci sono abbastanza prodotti per completare l'ordine!");
				
			else {
				oggetto.setQuantit�(order);
				}
    		
				
            carrello.aggiungi(oggetto);
            
        }
        else if (request.getParameter("azione").equals("Rimuovi")) {
        	
        	oggetto.setNome(request.getParameter("NomeA"));
        	oggetto.setDescrizione(request.getParameter("Descrizione"));
        	oggetto.setPrezzo(Double.parseDouble(request.getParameter("Prezzo")));
        	oggetto.setQuantit�(Integer.parseInt(request.getParameter("Quantit�")));
            carrello.rimuovi(oggetto);
        }
    	request.getSession().setAttribute("carrello", carrello.getOggettiCarrello());
        response.sendRedirect("carrello.jsp");
    }
}
