package Panel;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/catalog")
public class Catalog extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String page;
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();
    	
    	if (request.getParameter("azione").equals("Aggiungi Prodotto")) {
    		String n = request.getParameter("NomeA"); 
    		String d = request.getParameter("Descrizione");  
    		double p = Double.parseDouble(request.getParameter("Prezzo"));  
    		int q = Integer.parseInt(request.getParameter("Quantit�"));
           	
		try {  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mrrobot3d","root","root");  
			
			PreparedStatement ps=con.prepareStatement("insert into prodotto (Nome, Descrizione, Prezzo, Quantit�) "
					+ "values(?,?,?,?)"); 
			
			ps.setString(1,n);  
			ps.setString(2,d);     
			ps.setDouble(3,p);
			ps.setInt(4,q);
			ps.executeUpdate();  
			
		} catch (Exception e2) {
			System.out.println(e2);
			} 
       	
       	page = "catalogo.jsp";
    	response.sendRedirect(page);
		
    	 } else if (request.getParameter("azione").equals("Rimuovi")) {
    				
    		 int id = Integer.parseInt(request.getParameter("id"));
    		 
    		 try{
    			 
    			Class.forName("com.mysql.jdbc.Driver"); 
    					
    			Connection connessione = DriverManager.getConnection("jdbc:mysql://localhost:3306/mrrobot3d","root", "root");
    				    
    			PreparedStatement ps=connessione.prepareStatement("DELETE FROM prodotto \n"
    				    	+ "WHERE CodProdotto = \""+ id +"\"");
   
    			ps.executeUpdate();
    			
    				 } catch (Exception e2) {
    						System.out.println(e2);
    						} 
    		 
    		 out.print(id);
             
           /*  page = "catalogo.jsp";
             response.sendRedirect(page);*/
    		 
    	 } else if (request.getParameter("azione").equals("Aggiorna")){
    		 
    		 int id = Integer.parseInt(request.getParameter("id"));
    		 String n = request.getParameter("NomeA"); 
     		 String d = request.getParameter("Descrizione");  
     		 double p = Double.parseDouble(request.getParameter("Prezzo"));  
     		 int q = Integer.parseInt(request.getParameter("Quantit�"));
    		 
    		 try{
    			 
     			Class.forName("com.mysql.jdbc.Driver"); 
     					
     			Connection connessione = DriverManager.getConnection("jdbc:mysql://localhost:3306/mrrobot3d","root", "root");
     				    
     			PreparedStatement ps=connessione.prepareStatement("UPDATE mrrobot3d.prodotto \n" +
     					"SET Nome = ?, Descrizione = ?, Prezzo = ?, Quantit� = ? \n" +
     					"WHERE CodProdotto = "+ id);
    
     			ps.setString(1, n);
     			ps.setString(2, d);
     			ps.setDouble(3, p);
     			ps.setInt(4, q);
     			
     			ps.executeUpdate();
     			
     				 } catch (Exception e2) {
     						System.out.println(e2);
     						} 
    		 page = "catalogo.jsp";
       		 response.sendRedirect(page);
    		 
    	 }
		
		out.close();  
}

}
